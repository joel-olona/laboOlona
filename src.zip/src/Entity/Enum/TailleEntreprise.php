<?php
namespace App\Entity\Enum;

enum TailleEntreprise: string
{
    const SIZE_SMALL = 'SM';
    const SIZE_MEDIUM = 'MD';
    const SIZE_LARGE = 'LG';
}